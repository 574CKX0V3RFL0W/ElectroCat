"""ElectroCat: local electronics inventory."""
